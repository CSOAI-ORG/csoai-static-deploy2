# CSOAI GSPC Cards — signed training fuel (CodaBench)
Issuer: CSOAI Ltd (UK 16939677). Measurement, not certification.
- cards-train.jsonl: 31,113 chat pairs from 1,087 signed h3k cards (16 axes)
- cards-manifest.json: per-axis field counts
- sample-card.json: one ed25519-signed h3k card (verifiable envelope)
Licence: CC-BY-4.0. Deterministic-graded; registers: MEASURED / REPORTED / UNMEASURED.
Generated 2026-08-19T12:46Z.