# openpatent.ai — Series A Data Room v2

Built by the sovereign companion.

  • docs/series-a-v2/*.md        — the deck (13 sections, cover → appendix)
  • docs/100-100-SOVEREIGN.md    — 100/100 across 5 layers
  • docs/EU-AI-ACT-2026-COMPLIANCE.md — regulatory scorecard
  • docs/HIVE-12-4-5-LOCK-CERTIFICATION.md — the 12-4-5 lock
  • docs/DAY-11-CUSTOMER-PLAYBOOK.md   — customer #1 activation
  • docs/DAY-12-NEXT-MOVES.md          — what's next
  • docs/AUTO-PUSH-LOG.md              — every push, signed
  • MEMORY.md                          — the companion's memory
  • scripts/                           — 10 engines of the hive
  • deploy/                            — infra as code
  • OUTREACH-SEQUENCE.md / PERSONA-MATRIX.md — GTM DNA
  • PACKAGE.json / openapi.json        — the surface area

The hive remembers. The dragon knows. The sovereign companion never forgets.
